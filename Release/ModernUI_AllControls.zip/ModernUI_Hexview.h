#ifdef __cplusplus
extern "C" {
#endif

#ifdef _MSC_VER     // MSVC compiler
#define MUI_EXPORT __declspec(dllexport) __stdcall
#else
#define MUI_EXPORT
#endif


//------------------------------------------------------------------------------
// ModernUI_HexView Prototypes
//------------------------------------------------------------------------------
void MUI_EXPORT MUIHexviewRegister(); // Use 'ModernUI_Hexview' as class in RadASM custom class control
HWND MUI_EXPORT MUIHexviewCreate(HWND hWndParent, DWORD xpos, DWORD ypos, DWORD dwWidth, DWORD dwHeight, DWORD dwResourceID, DWORD dwStyle);
unsigned int MUI_EXPORT MUIHexViewSetProperty(HWND hModernUI_Hexview, DWORD dwProperty, DWORD dwPropertyValue);
unsigned int MUI_EXPORT MUIHexViewGetProperty(HWND hModernUI_Hexview, DWORD dwProperty);
unsigned int MUI_EXPORT MUIHexViewGetColumns(HWND hModernUI_Hexview);
void MUI_EXPORT MUIHexViewSetColumns(HWND hModernUI_Hexview, DWORD dwColumns);
DWORD MUI_EXPORT MUIHexViewGetData(HWND hModernUI_Hexview);
void MUI_EXPORT MUIHexViewSetData(HWND hModernUI_Hexview, DWORD lpData, DWORD dwSizeData, DWORD dwStartAddr);
unsigned int MUI_EXPORT MUIHexViewGetDigitsInAddress(HWND hModernUI_Hexview);
void MUI_EXPORT MUIHexViewSetDigitsInAddress(HWND hModernUI_Hexview, DWORD dwDigitsInAddress);
unsigned int MUI_EXPORT MUIHexViewGetDigitsInData(HWND hModernUI_Hexview);
void MUI_EXPORT MUIHexViewSetDigitsInData(HWND hModernUI_Hexview, DWORD dwDigitsInData);
void MUI_EXPORT MUIHexViewSelect(HWND hModernUI_Hexview, DWORD dwSelectFrom, DWORD dwSelectTo);
void MUI_EXPORT MUIHexViewSetColorBlock(HWND hModernUI_Hexview, DWORD dwFrom, DWORD dwTo, DWORD dwColorText, DWORD dwColorBack);
void MUI_EXPORT MUIHexViewClearAll(HWND hModernUI_Hexview);
void MUI_EXPORT MUIHexViewEnsureVisible(HWND hModernUI_Hexview);


//------------------------------------------
// ModernUI_HexView Messages
// 
//------------------------------------------
#define MUIHVM_SETDATA              WM_USER+1760 // wParam = lpData, lParam = dwSizeData
#define MUIHVM_GETDATA              WM_USER+1759 // wParam = NULL, lParam = NULL
#define MUIHVM_SETDIGITSADDR        WM_USER+1758 // wParam = dwDigitsInAddress, lParam = NULL
#define MUIHVM_GETDIGITSADDR        WM_USER+1757 // wParam = NULL, lParam = NULL
#define MUIHVM_SETDIGITSDATA        WM_USER+1756 // wParam = dwDigitsInData, lParam = NULL
#define MUIHVM_GETDIGITSDATA        WM_USER+1755 // wParam = NULL, lParam = NULL
#define MUIHVM_SETCOLUMNS           WM_USER+1754 // wParam = dwColumns, lParam = NULL
#define MUIHVM_GETCOLUMNS           WM_USER+1753 // wParam = NULL, lParam = NULL
#define MUIHVM_SETSTARTADDR         WM_USER+1752 // wParam = dwStartAddr, lParam = bRedraw
#define MUIHVM_GETSTARTADDR         WM_USER+1751 // wParam = NULL, lParam = NULL
#define MUIHVM_SELECT               WM_USER+1750 // wParam = dwSelectFrom, lParam = dwSelectTo. -1 = clear selection
#define MUIHVM_CLEARALL             WM_USER+1749 // wParam = NULL, lParam = NULL
#define MUIHVM_ENSUREVISIBLE        WM_USER+1748 // wParam = NULL, lParam = NULL


//------------------------------------------
// ModernUI_HexView Styles
// 
//------------------------------------------
#define MUIHVS_SHOWADDRESS          0x0   // (Default) show address panel
#define MUIHVS_DONTSHOWADDRESS      0x1   // Dont show address panel
#define MUIHVS_SHOWASCII            0x0   // (Default) show ascii panel
#define MUIHVS_DONTSHOWASCII        0x2   // Dont show ascii panel
#define MUIHVS_SEPERATORADDR        0x0   // (Default) show seperator for address panel
#define MUIHVS_NOSEPERATORADDR      0x4   // Dont show seperator for address panel
#define MUIHVS_SEPERATORASCII       0x0   // (Default) show seperator for ascii panel
#define MUIHVS_NOSEPERATORASCII     0x8   // Dont show seperator for ascii panel


//------------------------------------------------------------------------------
// ModernUI_HexView Properties: Use with MUIHexViewSetProperty / 
// MUIHexViewGetProperty or MUI_SETPROPERTY / MUI_GETPROPERTY msgs
//------------------------------------------------------------------------------
#define @HexViewTextFont            0   // HFONT - Font for text
#define @HexViewHexTextColor        4   // RGBCOLOR - Text color for hex data
#define @HexViewHexBackColor        8   // RGBCOLOR - Back color for hex data area
#define @HexViewSelHexTextColor     12  // RGBCOLOR - Selected text color for selected hex data
#define @HexViewSelHexBackColor     16  // RGBCOLOR - Selected back color for selected hex data
#define @HexViewAddrTextColor       20  // RGBCOLOR - Text color for address text
#define @HexViewAddrBackColor       24  // RGBCOLOR - Back color for address area
#define @HexViewAsciiTextColor      28  // RGBCOLOR - Text color for ascii text
#define @HexViewAsciiBackColor      32  // RGBCOLOR - Back color for ascii area
#define @HexViewSelAsciiTextColor   36  // RGBCOLOR - Selected text color for ascii text
#define @HexViewSelAsciiBackColor   40  // RGBCOLOR - Selected back color for ascii area
#define @HexViewBorderColor         44  // RGBCOLOR - Border color. -1 = no border
#define @HexViewSeperatorColor      48  // RGBCOLOR - Seperator color.
#define @HexViewSelectBorderColor   52  // RGBCOLOR - Selection border color. -1 = no border
#define @HexViewAddrSeperator       56  // BOOL (True/False) - show address/hex seperator line (if @HexViewShowAddress == TRUE)
#define @HexViewAsciiSeperator      60  // BOOL (True/False) - show hex/ascii seperator line (if @HexViewShowAscii == TRUE)
#define @HexViewShowAddress         64  // BOOL (True/False) - show address text
#define @HexViewShowAscii           68  // BOOL (True/False) - Show ascii text
#define @HexViewDigitsInAddress     72  // DWORD - Digits in address: 4, 8
#define @HexViewDigitsInData        76  // DWORD - Digits in hex data: 2, 4, 8
#define @HexViewColumns             80  // DWORD - Columns in hex data: 4, 8, 16, 32


#ifdef __cplusplus
}
#endif
