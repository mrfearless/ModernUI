#ifdef __cplusplus
extern "C" {
#endif

#ifdef _MSC_VER     // MSVC compiler
#define MUI_EXPORT __declspec(dllexport) __stdcall
#else
#define MUI_EXPORT
#endif


//------------------------------------------------------------------------------
// ModernUI_Hexview Prototypes
//------------------------------------------------------------------------------
void MUI_EXPORT MUIHexviewRegister(); // Use 'ModernUI_Hexview' as class in RadASM custom class control
HWND MUI_EXPORT MUIHexviewCreate(HWND hWndParent, DWORD xpos, DWORD ypos, DWORD dwWidth, DWORD dwHeight, DWORD dwResourceID, DWORD dwStyle);
unsigned int MUI_EXPORT MUIHexviewSetProperty(HWND hModernUI_Hexview, DWORD dwProperty, DWORD dwPropertyValue);
unsigned int MUI_EXPORT MUIHexviewGetProperty(HWND hModernUI_Hexview, DWORD dwProperty);
unsigned int MUI_EXPORT MUIHexviewGetColumns(HWND hModernUI_Hexview);
void MUI_EXPORT MUIHexviewSetColumns(HWND hModernUI_Hexview, DWORD dwColumns);
DWORD MUI_EXPORT MUIHexviewGetData(HWND hModernUI_Hexview);
void MUI_EXPORT MUIHexviewSetData(HWND hModernUI_Hexview, DWORD lpData, DWORD dwSizeData, DWORD dwStartAddr);
unsigned int MUI_EXPORT MUIHexviewGetDigitsInAddress(HWND hModernUI_Hexview);
void MUI_EXPORT MUIHexviewSetDigitsInAddress(HWND hModernUI_Hexview, DWORD dwDigitsInAddress);
unsigned int MUI_EXPORT MUIHexviewGetDigitsInData(HWND hModernUI_Hexview);
void MUI_EXPORT MUIHexviewSetDigitsInData(HWND hModernUI_Hexview, DWORD dwDigitsInData);
void MUI_EXPORT MUIHexviewSelect(HWND hModernUI_Hexview, DWORD dwSelectFrom, DWORD dwSelectTo);
void MUI_EXPORT MUIHexviewSetColorBlock(HWND hModernUI_Hexview, DWORD dwFrom, DWORD dwTo, DWORD dwColorText, DWORD dwColorBack);
void MUI_EXPORT MUIHexviewClearAll(HWND hModernUI_Hexview);
void MUI_EXPORT MUIHexviewEnsureVisible(HWND hModernUI_Hexview);


//------------------------------------------
// ModernUI_Hexview Messages
// 
//------------------------------------------
#define MUIHVM_SETDATA              WM_USER+1760 // wParam = lpData, lParam = dwSizeData
#define MUIHVM_GETDATA              WM_USER+1759 // wParam = NULL, lParam = NULL
#define MUIHVM_SETDIGITSADDR        WM_USER+1758 // wParam = dwDigitsInAddress, lParam = NULL
#define MUIHVM_GETDIGITSADDR        WM_USER+1757 // wParam = NULL, lParam = NULL
#define MUIHVM_SETDIGITSDATA        WM_USER+1756 // wParam = dwDigitsInData, lParam = NULL
#define MUIHVM_GETDIGITSDATA        WM_USER+1755 // wParam = NULL, lParam = NULL
#define MUIHVM_SETCOLUMNS           WM_USER+1754 // wParam = dwColumns, lParam = NULL
#define MUIHVM_GETCOLUMNS           WM_USER+1753 // wParam = NULL, lParam = NULL
#define MUIHVM_SETSTARTADDR         WM_USER+1752 // wParam = dwStartAddr, lParam = bRedraw
#define MUIHVM_GETSTARTADDR         WM_USER+1751 // wParam = NULL, lParam = NULL
#define MUIHVM_SELECT               WM_USER+1750 // wParam = dwSelectFrom, lParam = dwSelectTo. -1 = clear selection
#define MUIHVM_CLEARALL             WM_USER+1749 // wParam = NULL, lParam = NULL
#define MUIHVM_ENSUREVISIBLE        WM_USER+1748 // wParam = NULL, lParam = NULL


//------------------------------------------
// ModernUI_Hexview Styles
// 
//------------------------------------------
#define MUIHVS_SHOWADDRESS          0x0   // (Default) show address panel
#define MUIHVS_DONTSHOWADDRESS      0x1   // Dont show address panel
#define MUIHVS_SHOWASCII            0x0   // (Default) show ascii panel
#define MUIHVS_DONTSHOWASCII        0x2   // Dont show ascii panel
#define MUIHVS_SEPERATORADDR        0x0   // (Default) show seperator for address panel
#define MUIHVS_NOSEPERATORADDR      0x4   // Dont show seperator for address panel
#define MUIHVS_SEPERATORASCII       0x0   // (Default) show seperator for ascii panel
#define MUIHVS_NOSEPERATORASCII     0x8   // Dont show seperator for ascii panel


//------------------------------------------------------------------------------
// ModernUI_Hexview Properties: Use with MUIHexviewSetProperty / 
// MUIHexviewGetProperty or MUI_SETPROPERTY / MUI_GETPROPERTY msgs
//------------------------------------------------------------------------------
#define @HexviewTextFont            0   // HFONT - Font for text
#define @HexviewHexTextColor        4   // RGBCOLOR - Text color for hex data
#define @HexviewHexBackColor        8   // RGBCOLOR - Back color for hex data area
#define @HexviewSelHexTextColor     12  // RGBCOLOR - Selected text color for selected hex data
#define @HexviewSelHexBackColor     16  // RGBCOLOR - Selected back color for selected hex data
#define @HexviewAddrTextColor       20  // RGBCOLOR - Text color for address text
#define @HexviewAddrBackColor       24  // RGBCOLOR - Back color for address area
#define @HexviewAsciiTextColor      28  // RGBCOLOR - Text color for ascii text
#define @HexviewAsciiBackColor      32  // RGBCOLOR - Back color for ascii area
#define @HexviewSelAsciiTextColor   36  // RGBCOLOR - Selected text color for ascii text
#define @HexviewSelAsciiBackColor   40  // RGBCOLOR - Selected back color for ascii area
#define @HexviewBorderColor         44  // RGBCOLOR - Border color. -1 = no border
#define @HexviewSeperatorColor      48  // RGBCOLOR - Seperator color.
#define @HexviewSelectBorderColor   52  // RGBCOLOR - Selection border color. -1 = no border
#define @HexviewAddrSeperator       56  // BOOL (True/False) - show address/hex seperator line (if @HexviewShowAddress == TRUE)
#define @HexviewAsciiSeperator      60  // BOOL (True/False) - show hex/ascii seperator line (if @HexviewShowAscii == TRUE)
#define @HexviewShowAddress         64  // BOOL (True/False) - show address text
#define @HexviewShowAscii           68  // BOOL (True/False) - Show ascii text
#define @HexviewDigitsInAddress     72  // DWORD - Digits in address: 4, 8
#define @HexviewDigitsInData        76  // DWORD - Digits in hex data: 2, 4, 8
#define @HexviewColumns             80  // DWORD - Columns in hex data: 4, 8, 16, 32


#ifdef __cplusplus
}
#endif
